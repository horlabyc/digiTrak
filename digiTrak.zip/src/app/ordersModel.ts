export class Orders {
  id: string;
  name: string;
  phoneNumber: number;
  address: String;
  destination: String;
  weight: number;
  volume: number;
  content: string;
}
